//definiçao das variavies
let vida = 1;
let treino = 0;
let energia = 100;
let dias = 25;
let inventario = ["Água", "Comida", "Medalha da Sorte", "Fé"];
let emoções = [];
let calma = "Calma";

alert("Você é Edilio Francisco, um refugiado venezuelano. Deixando para trás sua família e amigos, você parte em uma jornada perigosa para o México em busca de uma nova vida e a chance de competir nas Olimpíadas.");
alert("Depois de uma longa e árdua jornada, você finalmente chega ao México. Agora, seu objetivo é treinar para as Olimpíadas de 2024, onde você representará a Equipe Olímpica de Refugiados no tiro esportivo com pistolas de ar 10mm.");
alert("Detalhe:\n-se energia chegar a 0 você perde");

while (dias > 0 && energia > 0 && vida > 0) {//Verifica se todos os parametros sao true
    alert("Dias restantes até a viagem: " + dias + "\nEnergia: " + energia + "\nPontos de Treino: " + treino);//mini tela para mostras os pontos

    let escolha = Number(prompt("O que você quer fazer hoje?\n[1] Treinar\n[2] Descansar\n[3] Fazer uma refeição\n[4] Meditar\n"));//escolha o que voce quiser 

    switch (escolha) {//vai verificar qual caso voce escolheu
        case 1://caso escolha o caso 1
            treino += 4;//mais 4 pontos de treino
            energia -= 10;//energia - 10 pontos de anergia
            dias -= 1;//dias - 1 dia
            alert("Você treinou e melhorou suas habilidades! Pontos de Treino: " + treino + "\nEnergia: " + energia);
            alterarHistoriaTreino();//leva ate a funçao "alterarHistoriaTreino"
            break;
        case 2://caso escolha o caso 2
            descansar();//leva ate a funçao "descansar"
            alterarHistoriaDescanso();//leva ate a funçao "alterarHistoriaDescanso"
            break;
        case 3://caso escolha o caso 3
            comer();//leva ate a funçao "comer"
            alterarHistoriaRefeicao();//leva ate a funçao "alterarHistoriaRefeicao"
            break;
        case 4://caso escolha o caso 4
            meditar();//leva ate a funçao "meditar"
            break;
        default://caso nao seja nenhum dos anteriores vai executar o codigo abaixo
            alert("Você decidiu não fazer nada hoje.");//escreve na tela
            dias -= 1;//vai tirar um dia dos 25
            break;//quebra o codigo para nao seguir para baixo o codigo
    }

    if (energia <= 0) {//se caso a sua energia chegar a 0 voce perde:
        alert("Você desmaiou de exaustão. O jogo acabou.");
        break;
    }
    if (dias <= 0) {//se os dias acabarem voce vai ser levado para funçao paris
        paris();
        break;
    }
}
//funçao feita para fazer a açao de descançar
function descansar() {
    let quantosDescansos = Number(prompt("Quantas horas você deseja descansar? (Cada hora de descanso recupera 10 pontos de energia)"));//vai ver quantas "vezes" voce quer descançar
    if (isNaN(quantosDescansos) || quantosDescansos <= 0) {//vai verificar se o valor nao é um valor invalido ou 0, entao vai executar o codigo abixo
        alert("Número inválido de horas. Você decidiu não descansar.");
        return;//Vai retornar a funçao
    }
    dias -= 1;//vai tirar 1 dos dias que restam
    energia += quantosDescansos * 10;// vai ver quantas "vezes" voce descançou e fazeer vezes 10
    if (energia > 100) energia = 100;//faz a energia so ir ate 100
    alert("Você descansou e recuperou energia! Energia atual: " + energia + " pontos.");
}
//funçao para fazer o ato de comer/beber no meu jogo
function comer() {
    let refeicao = prompt("Você deseja comer algo do seu inventário?\n[1] Água\n[2] Comida\n[0] Voltar");
    switch (refeicao) {
        case '1'://caso a pessoa digite 2 vai seguir esse codigo:
            if (inventario.includes("Água")) {//verifica se tem "Água" no uinventario,se for "true":
                energia += 10;//adiciona mais 10 pontos de energia
                inventario = inventario.filter(item => item !== "Água");//vai retirar a "comida" do array falso e criar um novo array true
                if (energia > 100) energia = 100;//faz a energia so ir ate 100
                alert("Você bebeu água e recuperou 10 pontos de energia! Energia atual: " + energia + " pontos.");
            } else {
                alert("Você não tem mais água.");
            }
            break;
        case '2'://caso a pessoa digite 2 vai seguir esse codigo:
            if (inventario.includes("Comida")) {//verifica se tem "comida" no uinventario,se for "true":
                energia += 20;//adiciona 20 de anergia
                inventario = inventario.filter(item => item !== "Comida");//vai retirar a "comida" do array falso e criar um novo array true
                if (energia > 100) energia = 100;//faz a energia so ir ate 100
                alert("Você comeu e recuperou 20 pontos de energia! Energia atual: " + energia + " pontos.");
            } else {
                alert("Você não tem mais comida.");
            }
            break;
        case '0'://caso a pessoa digite "0" vai seguior o codigo ate o break
            alert("Você decidiu não comer agora.");
            break;
        default://Caso nao for nenhum dos casos a cima
            alert("Opção inválida.");
            break;
    }
}
//Função para poder "meditar", meditar é uma funçao dentro do jogo.
function meditar() {
    alert("Você decidiu meditar. Isso ajudará a clarear sua mente e fortalecer sua determinação.");
    if (!emoções.includes("Calma")) {//Vai verificar se ja tem "Calma" no array "emoçoes",se nao tiver, segue o codigo abaixo ate terminar o "if"
        emoções.push(calma);//Vai adicionar "Calma" ao array "emoçoes"
        alert("Você ganhou um colecionável... A calma. Olhe como está o seu inventário de emoções: " + emoções.join(", "));
    }
    energia += 15;//adiciona +15 de energia
    if (energia > 100) energia = 100;//faz a energia so ir ate 100
    dias -= 1;
    alert("Você recuperou 15 pontos de energia e ganhou mais paz interior! Energia atual: " + energia + " pontos.");
}
//função para seguir um pequeno dialogo para caso voce treine
function alterarHistoriaTreino() {
    if (treino > 70) {//caso voce esteja com bastante "treino"
        alert("Sua habilidade de tiro está se tornando extraordinária! Você se sente mais confiante.");
    } else if (treino > 50) {//caso voce tenha mais de 50 de "treino"
        alert("Seu treinamento está começando a dar frutos. Você se sente cada vez mais preparado.");
    } else if (treino > 30) {//caso voce esteja com pouco treino
        alert("Você está no caminho certo, mas ainda há muito a melhorar.");
    } else {
        alert("Você ainda está começando, continue treinando para melhorar suas habilidades.");
    }
}
//função para seguir um pequeno dialogo para caso voce descanse
function alterarHistoriaDescanso() {
    if (energia > 80) {//caso voce esteja com bastante energia
        alert("Você está cheio de energia e pronto para enfrentar qualquer desafio.");
    } else if (energia > 50) {//caso voce tenha mais de 50 energia
        alert("O descanso ajudou, mas você ainda sente um pouco de cansaço.");
    } else {//caso voce esteja com pouca energia
        alert("Você está muito cansado e precisa de mais descanso.");
    }
}
//função para seguir um pequeno dialogo para caso voce coma ou beba algo de sua mochila
function alterarHistoriaRefeicao() {
    if (inventario.length < 2) {
        alert("Seu inventário está quase vazio. Você precisará encontrar mais suprimentos em breve.");
    } else {
        alert("Você se sente revigorado após a refeição, mas precisa racionar os recursos restantes.");
    }
}
//função para continuar a contar a hitoria e seguir para as funções das emoções
function paris() {
    alert("Você chegou às Olimpíadas de 2024 em Paris!");
    alert("Enquanto andava até o seu hotel, você encontra uma pessoa na rua que parece não ter comida. Você deseja fazer uma troca com ela?");
    let troca = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    while (troca !== 1 && troca !== 0) {//laço para verificar a escolha
        alert("Não encontramos essa opção. Por favor, escolha 1 para sim ou 0 para não.");
        troca = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    }

    if (troca === 1) {//seguir caso escolha 1
        alert("Você efetuou a troca com sucesso. A pessoa lhe dá uma emoção, que é a alegria.");
        emoções.push("Alegria");//adiciona "Alegria" ao array "emoçoes"
        vida++;
        alert("Olhe como está o seu inventário de emoções: \n" + emoções.join(", "));//mostra como esta o inventario das emoções
        alert("Você acabou de chegar ao seu hotel. Você deseja fazer o pagamento em dinheiro ou no cartão?");
        let dinheiroOuCartao = Number(prompt("Digite:\n[1] Dinheiro\n[2] Cartão"));
        while (dinheiroOuCartao !== 1 && dinheiroOuCartao !== 2) {
            alert("Não encontramos essa opção. Por favor, escolha 1 para dinheiro ou 2 para cartão.");
            dinheiroOuCartao = Number(prompt("Digite:\n[1] Dinheiro\n[2] Cartão"));
        }

        if (dinheiroOuCartao === 1) {//seguir caso escolha 1
            alert("Você tentou pagar em dinheiro, mas viu que esqueceu sua carteira e não tem dinheiro. Você não poderá participar das Olimpíadas porque os documentos estavam dentro da sua carteira.");
            alert("Mas você lembra que está com os seus documentos no bolso e o seu cartão está na capinha do seu celular. Você se sente muito aliviado.");
            medo();
        } else if (dinheiroOuCartao === 2) {//seguir caso escolha 2
            alert("Você leva um susto achando que esqueceu, mas lembra que está com os seus documentos no bolso e o seu cartão está na capinha do seu celular. Você se sente muito aliviado.");
            vida++;
            medo();
        }
    } else {//caso escolha um numero invalido
        alert("Que pena que você não trocou, poderia ser legal ver a emoção junto com as outras.");
        medo();//puxar a funçao medo
    }
}
//função para dar a chance para conseguir o sentimento medo
function medo() {
    alert("Você entrega o seu cartão e ele passa sem problemas. Ele lhe oferece uma oferta de dobro do preço, mas você ganhará uma emoção... O medo!");
    let dobroPreço = Number(prompt("Digite:\n[1] Sim\n[0] Não"));//escolha
    while (dobroPreço !== 1 && dobroPreço !== 0) {//laço para verificar a escolha
        alert("Não encontramos essa opção. Por favor, escolha 1 para sim ou 0 para não.");
        dobroPreço = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    }

    if (dobroPreço === 1) {
        emoções.push("Medo");
        alert("Você ganhou uma emoção, o medo. Olhe como está o seu inventário de emoções:\n" + emoções.join(", "));
        vida++;
        nojo();//puxar a funçao nojo
    } else if (dobroPreço === 0) {
        alert("Infelizmente você perdeu uma ótima oportunidade, mas a escolha é sua!");
        nojo();
    }
}
//função para dar a chance para conseguir o sentimento nojo
function nojo() {
    alert("Depois de um tempo, você fica cansado de ficar deitado e vai dar uma volta para ver se há algum restaurante para comer.");
    alert("A caminho do restaurante, você encontra seu amigo de infância. Você sugere que eles vão comer juntos, e ele aceita!");
    alert("Vocês entram no restaurante, se sentam na mesa, o garçom lhe traz o cardápio. Você escolhe um bife, mas seu amigo escolhe ostra cozida no vapor.");
    alert("Ele lhe faz uma proposta... Você come a ostra e ganha uma emoção.");
    let escolhaNojo = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    while (escolhaNojo !== 1 && escolhaNojo !== 0) {//verifica se nao colocou um numero invalido
        alert("Não encontramos essa opção. Por favor, escolha 1 para sim ou 0 para não.");
        escolhaNojo = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    }
    //verifica a escolha de resposta:
    if (escolhaNojo === 1) {
        alert("Seu amigo estende o prato e você pega a ostra, engolindo-a de uma vez. \nEdilio:\n-Haaaa, que nojento!");
        emoções.push("Nojo");
        vida++;
        alert("O seu amigo lhe dá uma emoção... O nojo. Olhe como está o seu inventário de emoções: " + emoções.join(", "));
        ansiedade();//puxar a funçao ansiedade
    } else if (escolhaNojo === 0) {
        alert("Pena que não quis fazer a 'troca'. Era um bom colecionável.");
        ansiedade();
    }
}
//função para dar a chance para conseguir o sentimento ansiedade
function ansiedade() {
    alert("No outro dia, você desce para tomar café da manhã no hotel. Enquanto se serve, uma criança chega e pergunta:\n-Oi senhor, eu queria lhe fazer uma pergunta para um trabalho de escola. Você costuma fumar quando está ansioso?");
    let escolhaAnsiedade = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    while (escolhaAnsiedade !== 1 && escolhaAnsiedade !== 0) {//verifica se nao colocou um numero invalido
        alert("Não encontramos essa opção. Por favor, escolha 1 para sim ou 0 para não.");
        escolhaAnsiedade = Number(prompt("Digite:\n[1] Sim\n[0] Não"));
    }

    if (escolhaAnsiedade === 1) {
        alert("A criança lhe fala que não é bom fumar, mas agradece.");
        competirNasOlimpiadas();
    } else if (escolhaAnsiedade === 0) {
        alert("A criança lhe diz que você está certo em não fumar e agradece por responder a pergunta.");
        emoções.push("Ansiedade");
        vida++;
        alert("Você ganhou o colecionável 'Ansiedade'. Olhe como está o seu inventário: " + emoções.join(", "));
        competirNasOlimpiadas();
    }
}
//função para verificar em que lugar voce ficou nas olimpiadas
function competirNasOlimpiadas() {
    if (treino > 70 && energia > 50) {
        alert("Chegou o dia de voce competir, sera que vai conseguir uma boa colocação???")
        alert("Incrível! Você treinou arduamente e estava bem descansado. Você ganha a medalha de ouro!");
        vida++;
        alert("Dados finais:\nEnergia: " + energia + "\nEmoções coletadas: " + emoções.join(", ") + "\nPontos de treino: " + treino + "\nPontos finais: " + vida + "/7");
        Fim();
    } else if (treino > 50 && energia > 30) {
        alert("Chegou o dia de voce competir, sera que vai conseguir uma boa colocação???")
        alert("Bom trabalho! Embora não estivesse em sua melhor forma, você ainda conseguiu ganhar a medalha de prata.");
        alert("Dados finais:\nEnergia: " + energia + "\nEmoções coletadas: " + emoções.join(", ") + "\nPontos de treino: " + treino + "\nPontos finais: " + vida + "/7");
        Fim();
    } else if (treino > 30 && energia > 20) {
        alert("Chegou o dia de voce competir, sera que vai conseguir uma boa colocação???")
        alert("Você fez o seu melhor, mas a falta de treino ou energia fez com que você ficasse com a medalha de bronze.");
        alert("Dados finais:\nEnergia: " + energia + "\nEmoções coletadas: " + emoções.join(", ") + "\nPontos de treino: " + treino + "\nPontos finais: " + vida + "/7");
        Fim();
    } else {
        alert("Chegou o dia de voce competir, sera que vai conseguir uma boa colocação???")
        alert("Infelizmente, a falta de treino e energia impediu que você obtivesse uma medalha. Mas sua jornada foi admirável!");
        alert("Dados finais:\nEnergia: " + energia + "\nEmoções coletadas: " + emoções.join(", ") + "\nPontos de treino: " + treino + "\nPontos finais: " + vida + "/7");
        Fim();
    }
}

function Fim() {//função para as considerações finais
    alert("O jogo acabou\nObrigado por jogar\nFeito por: Matheus Pereira");
}